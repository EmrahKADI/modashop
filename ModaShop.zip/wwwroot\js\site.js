﻿// ===== ModaShop - Site JavaScript =====

document.addEventListener('DOMContentLoaded', function () {
    // Update cart badge
    updateCartBadge();

    // Auto-dismiss alerts after 4 seconds
    document.querySelectorAll('.alert-dismissible').forEach(function (alert) {
        setTimeout(function () {
            var bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 4000);
    });

    // Navbar scroll effect
    window.addEventListener('scroll', function () {
        var navbar = document.querySelector('.navbar');
        if (navbar) {
            if (window.scrollY > 50) {
                navbar.classList.add('shadow');
            } else {
                navbar.classList.remove('shadow');
            }
        }
    });

    // Back to top on logo click
    document.querySelector('.navbar-brand')?.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});

function updateCartBadge() {
    fetch('/Cart/GetCartCount')
        .then(function (response) { return response.json(); })
        .then(function (data) {
            var badge = document.getElementById('cart-badge');
            if (badge) {
                if (data.count > 0) {
                    badge.textContent = data.count;
                    badge.style.display = 'inline';
                } else {
                    badge.style.display = 'none';
                }
            }
        })
        .catch(function () { /* ignore */ });
}

// Card number input formatting helper
function formatCardNumber(input) {
    var value = input.value.replace(/\s/g, '').replace(/[^0-9]/g, '');
    var parts = value.match(/.{1,4}/g);
    input.value = parts ? parts.join(' ') : value;
}

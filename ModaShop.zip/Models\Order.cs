using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ModaShop.Models;

public class Order
{
    public int Id { get; set; }

    public string? UserId { get; set; }

    [Required(ErrorMessage = "Ad Soyad zorunludur")]
    [StringLength(100)]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "E-posta zorunludur")]
    [EmailAddress(ErrorMessage = "Geçerli bir e-posta adresi giriniz")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Telefon zorunludur")]
    [Phone]
    public string Phone { get; set; } = string.Empty;

    [Required(ErrorMessage = "Adres zorunludur")]
    [StringLength(500)]
    public string Address { get; set; } = string.Empty;

    [Required(ErrorMessage = "Şehir zorunludur")]
    public string City { get; set; } = string.Empty;

    [Required(ErrorMessage = "Posta kodu zorunludur")]
    public string ZipCode { get; set; } = string.Empty;

    [Column(TypeName = "decimal(18,2)")]
    public decimal TotalAmount { get; set; }

    public string Status { get; set; } = "Beklemede";

    public string PaymentStatus { get; set; } = "Ödenmedi";

    public string? PaymentTransactionId { get; set; }

    [StringLength(4)]
    public string? CardLastFour { get; set; }

    public DateTime OrderDate { get; set; } = DateTime.UtcNow;

    public List<OrderItem> OrderItems { get; set; } = new();
}

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace ModaShop.Models.ViewModels;

public class ProductCreateViewModel
{
    [Required(ErrorMessage = "Ürün adı zorunludur")]
    [StringLength(200)]
    [Display(Name = "Ürün Adı")]
    public string Name { get; set; } = string.Empty;

    [StringLength(2000)]
    [Display(Name = "Açıklama")]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Fiyat zorunludur")]
    [Range(0.01, 999999.99)]
    [Display(Name = "Fiyat (₺)")]
    public decimal Price { get; set; }

    [Display(Name = "İndirimli Fiyat (₺)")]
    public decimal? DiscountPrice { get; set; }

    [Required(ErrorMessage = "Beden zorunludur")]
    [Display(Name = "Beden")]
    public string Size { get; set; } = "M";

    [Required(ErrorMessage = "Renk zorunludur")]
    [Display(Name = "Renk")]
    public string Color { get; set; } = "Siyah";

    [Display(Name = "Stok Adedi")]
    public int StockQuantity { get; set; } = 0;

    [Display(Name = "Aktif")]
    public bool IsActive { get; set; } = true;

    [Display(Name = "Öne Çıkan")]
    public bool IsFeatured { get; set; } = false;

    [Required(ErrorMessage = "Kategori zorunludur")]
    [Display(Name = "Kategori")]
    public int CategoryId { get; set; }

    [Display(Name = "Ürün Fotoğrafı 1")]
    public IFormFile? Image1 { get; set; }

    [Display(Name = "Ürün Fotoğrafı 2")]
    public IFormFile? Image2 { get; set; }

    [Display(Name = "Ürün Fotoğrafı 3")]
    public IFormFile? Image3 { get; set; }
}

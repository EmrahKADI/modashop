using Microsoft.AspNetCore.Mvc;
using ModaShop.Models;
using System.Text.Json;

namespace ModaShop.Controllers;

public class CartController : Controller
{
    private const string CartSessionKey = "ShoppingCart";

    private List<CartItem> GetCart()
    {
        var cartJson = HttpContext.Session.GetString(CartSessionKey);
        return string.IsNullOrEmpty(cartJson) 
            ? new List<CartItem>() 
            : JsonSerializer.Deserialize<List<CartItem>>(cartJson) ?? new List<CartItem>();
    }

    private void SaveCart(List<CartItem> cart)
    {
        HttpContext.Session.SetString(CartSessionKey, JsonSerializer.Serialize(cart));
    }

    public IActionResult Index()
    {
        var cart = GetCart();
        ViewBag.Total = cart.Sum(c => c.Total);
        return View(cart);
    }

    [HttpPost]
    public IActionResult Add(int productId, string productName, decimal price, string? imagePath, string size, string color, int quantity = 1)
    {
        var cart = GetCart();
        var existing = cart.FirstOrDefault(c => c.ProductId == productId && c.Size == size && c.Color == color);

        if (existing != null)
        {
            existing.Quantity += quantity;
        }
        else
        {
            cart.Add(new CartItem
            {
                ProductId = productId,
                ProductName = productName,
                Price = price,
                ImagePath = imagePath,
                Size = size,
                Color = color,
                Quantity = quantity
            });
        }

        SaveCart(cart);
        TempData["CartMessage"] = $"\"{productName}\" sepete eklendi!";
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult UpdateQuantity(int productId, string size, string color, int quantity)
    {
        var cart = GetCart();
        var item = cart.FirstOrDefault(c => c.ProductId == productId && c.Size == size && c.Color == color);

        if (item != null)
        {
            if (quantity <= 0)
                cart.Remove(item);
            else
                item.Quantity = quantity;
        }

        SaveCart(cart);
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Remove(int productId, string size, string color)
    {
        var cart = GetCart();
        cart.RemoveAll(c => c.ProductId == productId && c.Size == size && c.Color == color);
        SaveCart(cart);
        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Clear()
    {
        SaveCart(new List<CartItem>());
        return RedirectToAction("Index");
    }

    public IActionResult GetCartCount()
    {
        var cart = GetCart();
        return Json(new { count = cart.Sum(c => c.Quantity) });
    }
}

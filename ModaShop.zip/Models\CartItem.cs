namespace ModaShop.Models;

public class CartItem
{
    public int ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string? ImagePath { get; set; }
    public string Size { get; set; } = "M";
    public string Color { get; set; } = "Siyah";
    public int Quantity { get; set; } = 1;
    public decimal Total => Price * Quantity;
}

using System.ComponentModel.DataAnnotations;

namespace ModaShop.Models.ViewModels;

public class CheckoutViewModel
{
    [Required(ErrorMessage = "Ad Soyad zorunludur")]
    [Display(Name = "Ad Soyad")]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "E-posta zorunludur")]
    [EmailAddress(ErrorMessage = "Geçerli bir e-posta giriniz")]
    [Display(Name = "E-posta")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Telefon zorunludur")]
    [Phone]
    [Display(Name = "Telefon")]
    public string Phone { get; set; } = string.Empty;

    [Required(ErrorMessage = "Adres zorunludur")]
    [Display(Name = "Adres")]
    public string Address { get; set; } = string.Empty;

    [Required(ErrorMessage = "Şehir zorunludur")]
    [Display(Name = "Şehir")]
    public string City { get; set; } = string.Empty;

    [Required(ErrorMessage = "Posta kodu zorunludur")]
    [Display(Name = "Posta Kodu")]
    public string ZipCode { get; set; } = string.Empty;

    // Kart bilgileri
    [Required(ErrorMessage = "Kart üzerindeki isim zorunludur")]
    [Display(Name = "Kart Üzerindeki İsim")]
    public string CardHolderName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Kart numarası zorunludur")]
    [CreditCard(ErrorMessage = "Geçerli bir kart numarası giriniz")]
    [Display(Name = "Kart Numarası")]
    public string CardNumber { get; set; } = string.Empty;

    [Required(ErrorMessage = "Son kullanma ayı zorunludur")]
    [Range(1, 12)]
    [Display(Name = "Ay")]
    public int ExpiryMonth { get; set; }

    [Required(ErrorMessage = "Son kullanma yılı zorunludur")]
    [Range(2024, 2040)]
    [Display(Name = "Yıl")]
    public int ExpiryYear { get; set; }

    [Required(ErrorMessage = "CVV zorunludur")]
    [StringLength(4, MinimumLength = 3)]
    [Display(Name = "CVV")]
    public string CVV { get; set; } = string.Empty;

    public List<CartItem> CartItems { get; set; } = new();
    public decimal TotalAmount { get; set; }
}

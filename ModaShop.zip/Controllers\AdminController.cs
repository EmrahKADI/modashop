using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ModaShop.Data;
using ModaShop.Models;
using ModaShop.Models.ViewModels;

namespace ModaShop.Controllers;

[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly IWebHostEnvironment _env;

    public AdminController(ApplicationDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    public async Task<IActionResult> Index()
    {
        var totalProducts = await _context.Products.CountAsync();
        var totalOrders = await _context.Orders.CountAsync();
        var totalRevenue = await _context.Orders.Where(o => o.PaymentStatus == "Ödendi").SumAsync(o => o.TotalAmount);
        var recentOrders = await _context.Orders.OrderByDescending(o => o.OrderDate).Take(10).ToListAsync();

        ViewBag.TotalProducts = totalProducts;
        ViewBag.TotalOrders = totalOrders;
        ViewBag.TotalRevenue = totalRevenue;
        ViewBag.RecentOrders = recentOrders;

        return View();
    }

    public async Task<IActionResult> Products()
    {
        var products = await _context.Products.Include(p => p.Category).OrderByDescending(p => p.CreatedAt).ToListAsync();
        return View(products);
    }

    public async Task<IActionResult> CreateProduct()
    {
        ViewBag.Categories = new SelectList(await _context.Categories.ToListAsync(), "Id", "Name");
        return View(new ProductCreateViewModel());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateProduct(ProductCreateViewModel model)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Categories = new SelectList(await _context.Categories.ToListAsync(), "Id", "Name");
            return View(model);
        }

        var product = new Product
        {
            Name = model.Name,
            Description = model.Description,
            Price = model.Price,
            DiscountPrice = model.DiscountPrice,
            Size = model.Size,
            Color = model.Color,
            StockQuantity = model.StockQuantity,
            IsActive = model.IsActive,
            IsFeatured = model.IsFeatured,
            CategoryId = model.CategoryId,
            CreatedAt = DateTime.UtcNow
        };

        if (model.Image1 != null)
            product.ImagePath = await SaveImage(model.Image1);
        if (model.Image2 != null)
            product.ImagePath2 = await SaveImage(model.Image2);
        if (model.Image3 != null)
            product.ImagePath3 = await SaveImage(model.Image3);

        _context.Products.Add(product);
        await _context.SaveChangesAsync();

        TempData["Success"] = "Ürün başarıyla eklendi!";
        return RedirectToAction("Products");
    }

    public async Task<IActionResult> EditProduct(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product == null) return NotFound();

        var model = new ProductCreateViewModel
        {
            Name = product.Name,
            Description = product.Description,
            Price = product.Price,
            DiscountPrice = product.DiscountPrice,
            Size = product.Size,
            Color = product.Color,
            StockQuantity = product.StockQuantity,
            IsActive = product.IsActive,
            IsFeatured = product.IsFeatured,
            CategoryId = product.CategoryId
        };

        ViewBag.Categories = new SelectList(await _context.Categories.ToListAsync(), "Id", "Name", product.CategoryId);
        ViewBag.ProductId = id;
        ViewBag.CurrentImage = product.ImagePath;
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditProduct(int id, ProductCreateViewModel model)
    {
        var product = await _context.Products.FindAsync(id);
        if (product == null) return NotFound();

        if (!ModelState.IsValid)
        {
            ViewBag.Categories = new SelectList(await _context.Categories.ToListAsync(), "Id", "Name", product.CategoryId);
            ViewBag.ProductId = id;
            ViewBag.CurrentImage = product.ImagePath;
            return View(model);
        }

        product.Name = model.Name;
        product.Description = model.Description;
        product.Price = model.Price;
        product.DiscountPrice = model.DiscountPrice;
        product.Size = model.Size;
        product.Color = model.Color;
        product.StockQuantity = model.StockQuantity;
        product.IsActive = model.IsActive;
        product.IsFeatured = model.IsFeatured;
        product.CategoryId = model.CategoryId;

        if (model.Image1 != null)
            product.ImagePath = await SaveImage(model.Image1);
        if (model.Image2 != null)
            product.ImagePath2 = await SaveImage(model.Image2);
        if (model.Image3 != null)
            product.ImagePath3 = await SaveImage(model.Image3);

        await _context.SaveChangesAsync();

        TempData["Success"] = "Ürün başarıyla güncellendi!";
        return RedirectToAction("Products");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        var product = await _context.Products.FindAsync(id);
        if (product != null)
        {
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            TempData["Success"] = "Ürün silindi!";
        }
        return RedirectToAction("Products");
    }

    public async Task<IActionResult> Orders()
    {
        var orders = await _context.Orders
            .Include(o => o.OrderItems)
            .OrderByDescending(o => o.OrderDate)
            .ToListAsync();
        return View(orders);
    }

    public async Task<IActionResult> OrderDetails(int id)
    {
        var order = await _context.Orders
            .Include(o => o.OrderItems)
            .ThenInclude(oi => oi.Product)
            .FirstOrDefaultAsync(o => o.Id == id);

        if (order == null) return NotFound();
        return View(order);
    }

    private async Task<string> SaveImage(IFormFile file)
    {
        var uploadsDir = Path.Combine(_env.WebRootPath, "images", "products");
        Directory.CreateDirectory(uploadsDir);

        var fileName = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName)}";
        var filePath = Path.Combine(uploadsDir, fileName);

        using var stream = new FileStream(filePath, FileMode.Create);
        await file.CopyToAsync(stream);

        return $"/images/products/{fileName}";
    }
}

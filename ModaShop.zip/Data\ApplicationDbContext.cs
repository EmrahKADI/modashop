using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ModaShop.Models;

namespace ModaShop.Data;

public class ApplicationDbContext : IdentityDbContext<IdentityUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Category>().HasData(
            new Category { Id = 1, Name = "Kadın Giyim", Description = "Kadın kıyafetleri ve aksesuarlar" },
            new Category { Id = 2, Name = "Erkek Giyim", Description = "Erkek kıyafetleri ve aksesuarlar" },
            new Category { Id = 3, Name = "Çocuk Giyim", Description = "Çocuk kıyafetleri" },
            new Category { Id = 4, Name = "Ayakkabı", Description = "Her türlü ayakkabı modelleri" },
            new Category { Id = 5, Name = "Aksesuar", Description = "Çanta, şal, takı ve diğer aksesuarlar" }
        );

        builder.Entity<Product>().HasData(
            new Product { Id = 1, Name = "Siyah Deri Ceket", Description = "Premium kalite gerçek deri ceket. Slim fit kesim, fermuar detaylı.", Price = 2499.99m, DiscountPrice = 1999.99m, Size = "M", Color = "Siyah", StockQuantity = 25, IsActive = true, IsFeatured = true, CategoryId = 2, ImagePath = "/images/products/deri-ceket.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 2, Name = "Floral Yazlık Elbise", Description = "Hafif kumaş, çiçek desenli yazlık elbise. Rahat kesim.", Price = 899.99m, Size = "S", Color = "Pembe", StockQuantity = 40, IsActive = true, IsFeatured = true, CategoryId = 1, ImagePath = "/images/products/floral-elbise.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 3, Name = "Slim Fit Kot Pantolon", Description = "Yüksek kalite denim, slim fit kesim kot pantolon.", Price = 599.99m, DiscountPrice = 449.99m, Size = "32", Color = "Mavi", StockQuantity = 60, IsActive = true, IsFeatured = true, CategoryId = 2, ImagePath = "/images/products/kot-pantolon.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 4, Name = "Oversize Hoodie", Description = "Unisex oversize hoodie. Yumuşak pamuklu kumaş.", Price = 449.99m, Size = "L", Color = "Gri", StockQuantity = 80, IsActive = true, IsFeatured = true, CategoryId = 2, ImagePath = "/images/products/hoodie.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 5, Name = "Kadın Trençkot", Description = "Klasik kesim kadın trençkot. Su geçirmez kumaş.", Price = 1799.99m, DiscountPrice = 1299.99m, Size = "M", Color = "Bej", StockQuantity = 15, IsActive = true, IsFeatured = true, CategoryId = 1, ImagePath = "/images/products/trencot.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 6, Name = "Spor Ayakkabı", Description = "Hafif ve esnek taban, günlük kullanıma uygun spor ayakkabı.", Price = 1299.99m, Size = "42", Color = "Beyaz", StockQuantity = 50, IsActive = true, IsFeatured = true, CategoryId = 4, ImagePath = "/images/products/spor-ayakkabi.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 7, Name = "Çocuk Yağmurluk", Description = "Renkli desenli çocuk yağmurluğu. Su geçirmez.", Price = 349.99m, Size = "8-9 Yaş", Color = "Sarı", StockQuantity = 30, IsActive = true, CategoryId = 3, ImagePath = "/images/products/cocuk-yagmurluk.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 8, Name = "Deri Omuz Çantası", Description = "El yapımı gerçek deri omuz çantası. Geniş iç hacim.", Price = 1599.99m, DiscountPrice = 1199.99m, Size = "Tek Ebat", Color = "Kahverengi", StockQuantity = 20, IsActive = true, IsFeatured = true, CategoryId = 5, ImagePath = "/images/products/omuz-cantasi.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 9, Name = "Pamuklu Basic T-Shirt", Description = "%100 organik pamuk basic t-shirt. Geniş renk seçeneği.", Price = 199.99m, Size = "M", Color = "Beyaz", StockQuantity = 200, IsActive = true, CategoryId = 2, ImagePath = "/images/products/basic-tshirt.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 10, Name = "Kadın Topuklu Sandalet", Description = "Şık ince topuk detaylı sandalet. Parti ve davetlere uygun.", Price = 999.99m, DiscountPrice = 749.99m, Size = "38", Color = "Siyah", StockQuantity = 25, IsActive = true, CategoryId = 4, ImagePath = "/images/products/topuklu-sandalet.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 11, Name = "Keten Gömlek", Description = "Saf keten yazlık gömlek. Nefes alabilir kumaş.", Price = 699.99m, Size = "L", Color = "Beyaz", StockQuantity = 45, IsActive = true, CategoryId = 2, ImagePath = "/images/products/keten-gomlek.jpg", CreatedAt = DateTime.Parse("2024-01-01") },
            new Product { Id = 12, Name = "İpek Şal", Description = "El boyaması %100 ipek şal. Özel tasarım desenler.", Price = 899.99m, DiscountPrice = 699.99m, Size = "Tek Ebat", Color = "Bordo", StockQuantity = 15, IsActive = true, IsFeatured = true, CategoryId = 5, ImagePath = "/images/products/ipek-sal.jpg", CreatedAt = DateTime.Parse("2024-01-01") }
        );
    }
}

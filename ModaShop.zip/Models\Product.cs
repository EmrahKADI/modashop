using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ModaShop.Models;

public class Product
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Ürün adı zorunludur")]
    [StringLength(200)]
    public string Name { get; set; } = string.Empty;

    [StringLength(2000)]
    public string? Description { get; set; }

    [Required(ErrorMessage = "Fiyat zorunludur")]
    [Column(TypeName = "decimal(18,2)")]
    [Range(0.01, 999999.99, ErrorMessage = "Fiyat 0'dan büyük olmalıdır")]
    public decimal Price { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal? DiscountPrice { get; set; }

    public string? ImagePath { get; set; }
    public string? ImagePath2 { get; set; }
    public string? ImagePath3 { get; set; }

    [Required]
    public string Size { get; set; } = "M";

    [Required]
    public string Color { get; set; } = "Siyah";

    public int StockQuantity { get; set; } = 0;

    public bool IsActive { get; set; } = true;
    public bool IsFeatured { get; set; } = false;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public int CategoryId { get; set; }
    public Category? Category { get; set; }

    [NotMapped]
    public decimal DisplayPrice => DiscountPrice ?? Price;

    [NotMapped]
    public bool HasDiscount => DiscountPrice.HasValue && DiscountPrice < Price;

    [NotMapped]
    public int DiscountPercent => HasDiscount
        ? (int)Math.Round((1 - DiscountPrice!.Value / Price) * 100)
        : 0;
}

using Microsoft.AspNetCore.Mvc;
using ModaShop.Data;
using ModaShop.Models;
using ModaShop.Models.ViewModels;
using System.Text.Json;

namespace ModaShop.Controllers;

public class CheckoutController : Controller
{
    private readonly ApplicationDbContext _context;
    private const string CartSessionKey = "ShoppingCart";

    public CheckoutController(ApplicationDbContext context)
    {
        _context = context;
    }

    private List<CartItem> GetCart()
    {
        var cartJson = HttpContext.Session.GetString(CartSessionKey);
        return string.IsNullOrEmpty(cartJson)
            ? new List<CartItem>()
            : JsonSerializer.Deserialize<List<CartItem>>(cartJson) ?? new List<CartItem>();
    }

    public IActionResult Index()
    {
        var cart = GetCart();
        if (!cart.Any())
            return RedirectToAction("Index", "Cart");

        var viewModel = new CheckoutViewModel
        {
            CartItems = cart,
            TotalAmount = cart.Sum(c => c.Total)
        };

        return View(viewModel);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> PlaceOrder(CheckoutViewModel model)
    {
        var cart = GetCart();
        if (!cart.Any())
            return RedirectToAction("Index", "Cart");

        model.CartItems = cart;
        model.TotalAmount = cart.Sum(c => c.Total);

        if (!ModelState.IsValid)
            return View("Index", model);

        // Simulate payment processing
        var paymentSuccess = SimulatePayment(model.CardNumber, model.ExpiryMonth, model.ExpiryYear, model.CVV, model.TotalAmount);

        if (!paymentSuccess)
        {
            ModelState.AddModelError("", "Ödeme işlemi başarısız oldu. Lütfen kart bilgilerinizi kontrol edin.");
            return View("Index", model);
        }

        var order = new Order
        {
            FullName = model.FullName,
            Email = model.Email,
            Phone = model.Phone,
            Address = model.Address,
            City = model.City,
            ZipCode = model.ZipCode,
            TotalAmount = model.TotalAmount,
            Status = "Onaylandı",
            PaymentStatus = "Ödendi",
            PaymentTransactionId = Guid.NewGuid().ToString("N")[..12].ToUpper(),
            CardLastFour = model.CardNumber.Length >= 4 ? model.CardNumber[^4..] : model.CardNumber,
            OrderDate = DateTime.UtcNow,
            UserId = User.Identity?.IsAuthenticated == true ? User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value : null,
            OrderItems = cart.Select(c => new OrderItem
            {
                ProductId = c.ProductId,
                ProductName = c.ProductName,
                Size = c.Size,
                Color = c.Color,
                Quantity = c.Quantity,
                UnitPrice = c.Price
            }).ToList()
        };

        _context.Orders.Add(order);
        await _context.SaveChangesAsync();

        // Clear cart
        HttpContext.Session.Remove(CartSessionKey);

        return RedirectToAction("Success", new { id = order.Id });
    }

    public async Task<IActionResult> Success(int id)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null) return NotFound();
        return View(order);
    }

    private bool SimulatePayment(string cardNumber, int expiryMonth, int expiryYear, string cvv, decimal amount)
    {
        // Demo: Accept all cards except those starting with "0000"
        if (cardNumber.Replace(" ", "").StartsWith("0000"))
            return false;

        // Simulate processing delay
        Thread.Sleep(500);
        return true;
    }
}
